Movie Recommendation System - Analysis Package
================================================

This package contains the results of a collaborative filtering analysis.

Files included:
- dataset.json: The dataset used in JSON format
- dataset.csv: The dataset in CSV format
- recommendations.json: Generated recommendations for users
- metadata.json: Technical details about the analysis
- README.txt: This file

Analysis Details:
- Dataset Type: realistic
- Total Users: 90
- Total Movies: 150
- Total Ratings: 6750
- Dataset Sparsity: 50.00%

Usage:
- Load dataset.json or dataset.csv into your recommendation system
- Use recommendations.json to see example recommendations
- Check metadata.json for technical parameters

For questions about this analysis, please refer to the original system documentation.
